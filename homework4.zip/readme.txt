Requirements:

python
pandas
networkx
matplotlib

How to execute:

On command line, digit "python homework4.py"

Output: Degree probability distribution plot of network