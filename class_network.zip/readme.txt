Requirements:

python
pandas
numpy
networkx
matplotlib

How to execute:

On command line, digit "python class_network.py"

Output: Degree scatter of networks, graph metrics, visualization on matplotlib and .gexf files for gephi