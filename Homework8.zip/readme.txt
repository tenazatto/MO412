Requirements:

python
pandas
numpy
networkx
matplotlib

How to execute:

On command line, digit "python homework8.py (max_t)"

(max_t) is a parameter to limit the time step and is optional. If the parameter is passed, limit value of t to 1 <= t <= max_t. This is done due to performance issues cases and time constraints.
If the parameter isn't passed, the maximum value of t is the maximum determined by python.

Examples:
python homework8.py 3
python homework8.py 155
python homework8.py 1500
python homework8.py

Output: Degree scatter of networks, degree exponent and rate equation/book statement verify