import random

import networkx as nx
import pandas as pd
import matplotlib.pyplot as plt

def select_sample_nodes():
    nodes = range(1, 1001)
    sample_nodes = random.sample(nodes, 100)

    with open("nodes.tsv", "w") as nodes_data:
        for node_idx in enumerate(sample_nodes):
            nodes_data.write("v" + str(node_idx[0]) + "\t" + str(node_idx[1]) + "\n")

    return sample_nodes


def compute_shortest_paths(sample_nodes):
    graph_data = open('net1000-005.tsv', "r")
    graph_type = nx.Graph()

    graph = nx.parse_edgelist(graph_data, comments='t', delimiter='\t', create_using=graph_type,
                          nodetype=int, data=(('weight', float),))

    paths = []
    with open("paths.tsv", "w") as paths_data:
        for i in range(0,50,2):
            path = nx.shortest_path(graph, source=sample_nodes[i], target=sample_nodes[i+1])
            paths.append(path)
            for node in path:
                paths_data.write(str(node))
                if node != path[-1]:
                    paths_data.write("\t")
            paths_data.write("\n")

    return paths


def plot_distance_distribution(shortest_paths):
    distances = list(map(lambda path: len(path) - 1, shortest_paths))

    df = pd.DataFrame(distances, columns=['Distance'])
    dfc = df.groupby('Distance')['Distance'].count().reset_index(name='counts')
    dfc['counts'] = dfc['counts'].div(dfc['counts'].sum())
    dfc = dfc.rename(columns={'counts': 'Probability'})
    print('Distance probability distribution:\n', dfc)

    dfc.plot(kind='bar', x='Distance', y='Probability', title='Distance probability distribution')
    plt.show()


def main():
    sample_nodes = select_sample_nodes()
    shortest_paths = compute_shortest_paths(sample_nodes)
    plot_distance_distribution(shortest_paths)

if __name__ == '__main__':
    main()