Requirements:

python
pandas
networkx
matplotlib

How to execute:

On command line, digit "python homework3.py"

Input: TSV homework file
Output: TSV files of random nodes and paths, and distance probability distribution plot