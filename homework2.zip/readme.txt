Requirements:

python
pandas
networkx
matplotlib

How to execute:

On command line, digit "python homework2.py"

Input: TSV homework file
Output: Degree mean, probabilities of each degree and degree probability distribution plot