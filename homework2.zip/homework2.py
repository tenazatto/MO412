import networkx as nx
import pandas as pd
import matplotlib.pyplot as plt

def main():
    graph_data = open('net1000-005.tsv', "r")
    graph_type = nx.Graph()

    graph = nx.parse_edgelist(graph_data, comments='t', delimiter='\t', create_using=graph_type,
                          nodetype=int, data=(('weight', float),))

    df = pd.DataFrame(graph.degree, columns=['Node', 'Degree'])
    print('Graph degree mean:', df['Degree'].mean())

    dfb = df.groupby('Degree')['Degree'].count().reset_index(name='counts')
    dfb['counts'] = dfb['counts'].div(dfb['counts'].sum())
    dfb = dfb.rename(columns={'counts': 'Probability'})

    print('Degree probability distribution:\n', dfb)
    dfb.plot(kind='bar', x='Degree', y='Probability', title='Graph degree probability distribution')

    plt.show()

if __name__ == '__main__':
    main()