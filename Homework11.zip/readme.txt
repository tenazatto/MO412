Requirements:

python
networkx

How to execute:

On command line, digit "python homework11.py"

Input: netM.csv file

Output: Communities conparison (equal/different) and files of each community for each algorithm