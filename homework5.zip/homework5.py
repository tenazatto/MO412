import networkx as nx
import pandas as pd
import matplotlib.pyplot as plt

def main():
    graph1 = read_graph_from_file('net1.tsv')
    graph2 = read_graph_from_file('net2.tsv')

    plot_distribution_loglog(graph1, 'Graph 1', 1)
    plot_distribution_loglog(graph2, 'Graph 2', 2)
    plt.show()


def read_graph_from_file(filename):
    graph_data = open(filename, "r")
    graph_type = nx.Graph()
    graph = nx.parse_edgelist(graph_data, comments='t', delimiter='\t', create_using=graph_type,
                              nodetype=int, data=(('weight', float),))
    return graph


def plot_distribution_loglog(graph, title, order):
    df = pd.DataFrame(graph.degree, columns=['Node', 'Degree'])
    print('Graph degree mean:', df['Degree'].mean())
    dfb = df.groupby('Degree')['Degree'].count().reset_index(name='counts')
    dfb['counts'] = dfb['counts'].div(dfb['counts'].sum())
    dfb = dfb.rename(columns={'counts': 'Probability'})
    print('Degree probability distribution:\n', dfb)

    dfb.plot(x='Degree', y='Probability', title=f'{title} - Degree probability distribution')
    plt.yscale('log')
    plt.xscale('log')


if __name__ == '__main__':
    main()