Requirements:

python
pandas
networkx
matplotlib

How to execute:

On command line, digit "python homework5.py"

Input: TSV homework files
Output: Degree mean, probabilities of each degree and degree probability distribution plots in log-log scale