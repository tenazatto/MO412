Requirements:

python
pandas
numpy
scipy
networkx
matplotlib

How to execute:

On command line, digit "python homework10.py"

Input: netA.txt file, and ratio tolerance to find 50% ratio

Output: Degree scatter of P∞( f)/P∞(0), degree exponent, degree mean, critical threshold and value of f when P∞( f)/P∞(0) = 50%