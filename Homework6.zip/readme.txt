Requirements:

python
pandas
numpy
networkx
matplotlib

How to execute:

On command line, digit "python homework6.py"

Output: Degree scatter of network, and Network Degree Exponent trendline